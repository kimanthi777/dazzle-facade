defmodule Counter.Mailer do
  use Swoosh.Mailer, otp_app: :counter
end
