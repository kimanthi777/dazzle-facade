defmodule CounterWeb.CounterHTML do
  use CounterWeb, :html

  embed_templates "counter_html/*"
end
