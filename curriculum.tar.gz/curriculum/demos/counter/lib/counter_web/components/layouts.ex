defmodule CounterWeb.Layouts do
  use CounterWeb, :html

  embed_templates "layouts/*"
end
