# Projects

This folder will contain any projects you complete during DockYard Academy, except for projects that require creating a separate GitHub Repository such as your capstone.