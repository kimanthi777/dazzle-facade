defmodule Utils.Notebooks.NotebookTest do
  use ExUnit.Case
  doctest Utils.Notebooks.Notebook
end
