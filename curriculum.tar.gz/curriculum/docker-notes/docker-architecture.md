Containers are a software package into a logical box with everything that the application needs to run. That includes the operating system, application code, runtime, system tools, system libraries, and etc[file system]. Docker containers are built off Docker images.

Images are read only. Why?

- To give consistency: contents of an image cannot be modified accidentally or inadvertently during runtime. This helps maintain the integrity and consistency of the application, as the image contents remain fixed and unchanged.
- Security: By making images read-only, Docker minimizes the risk of unauthorized modification or tampering with the application code, runtime, or dependencies during runtime.
- Reproducibility: Docker images are intended to be reproducible, meaning that the same image can be used to create identical containers across different environments, such as development, testing, and production. By making images read-only, Docker ensures that the contents of an image remain unchanged, ensuring consistent behavior across different deployments.

Since images are read-only, Docker adds a read-write file system over the read-only file system of the image to create a container.
Docker containers are created from Docker images, which are read-only snapshots of a pre-configured file system that includes the application code, runtime, system tools, libraries, and other dependencies.

When a Docker container is started from an image, Docker adds a read-write file system layer on top of the read-only file system of the image. This read-write layer allows the container to store any changes made during runtime, such as writing logs, modifying configuration files, or updating data. This read-write file system layer is unique to each container and is not persisted in the image, which means that any changes made in the container do not affect the original image.

This "copy-on-write" mechanism used by Docker allows for efficient containerization, as multiple containers can share the same read-only image while having their own isolated read-write file system layer. It also enables fast and lightweight container creation and deployment, as only the changes made in the container need to be persisted and stored, rather than duplicating the entire image for each container.
