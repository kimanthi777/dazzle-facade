// Express App 1 - app.js
const express = require('express');
const app = express();

app.get('/', (req, res) => {
  res.send('Hello from Express App 1!');
});

app.get('/endpoint1', (req, res) => {
  res.send('Endpoint 1 of Express App 1');
});

app.listen(3001, () => {
  console.log('Express App 1 is listening on port 3001');
});
