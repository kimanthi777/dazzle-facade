const {klona} = require('klona')

const inputA = {
    foo: 1,
    bar: {
      baz: 2,
      bat: {
        hello: 'world'
      }
    }
};


const inputB = klona(inputA)

assert.deepStrictEqual(inputA, outputB);


// function checkEqual(inputA, inputB){
//     if(inputA==inputB){
//         console.log(true, 'object A equals B')
//     }
//     else{
//         console.log('!!')
//     }
// }

// checkEqual(inputA, inputB)