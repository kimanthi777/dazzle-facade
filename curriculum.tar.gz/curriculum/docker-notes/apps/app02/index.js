// Express App 2 - app.js
const express = require('express');
const app = express();

app.get('/', (req, res) => {
  res.send('Hello from Express App 2!');
});

app.get('/endpoint2', (req, res) => {
  res.send('Endpoint 2 of Express App 2');
});

app.listen(3002, () => {
  console.log('Express App 2 is listening on port 3002');
});
